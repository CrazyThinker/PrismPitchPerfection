#pragma once
#include "GeometryBuffer.h"

class CBatInfo
{
public:
	CGeometryBuffer vertex_Bat;
	CGeometryBuffer vertex_Preview;

	float Thick;
	float Length;
	float SweetSpotZone;

public:
	CBatInfo(void);
	~CBatInfo(void);

	void CreateBat1(GLuint program, float Thick, float Length, float SweetSpotZone);

};
