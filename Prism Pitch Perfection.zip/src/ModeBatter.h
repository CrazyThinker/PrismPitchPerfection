#pragma once
#include "ModeComponent.h"
#include "HitterBat.h"
#include "Pitcher.h"
#include "FileList.h"

enum eDifficulty {dStart, dShowBallType, dGuide, dSlow, dBigBat, dPowerfulSlugger};

class CModeBatter : public CModeComponent
{
public:
	CModeBatter(void);
	~CModeBatter(void);

public:
	CModeComponent* Main;
	int CursorDifficulty, Difficulty[5 + 1] = {0}, nDifficulty = 5;	// ���̵�, 1: ���� ǥ��, 2: ���ð��̵�, 3: �ӵ� ������, 4: ���� 2�� ��Ʈ, 5: ���� Ÿ��
	string strDifficulty[5 + 1] = { "Simulator Start", "Show Ball Type", "Batting Guide", "Slow Speed", "Big Bat", "Powerful Slugger" };
	int PitcherCursor;				// ����
	CBall BaseBall;					// Ball vector
	CHitterBat Bat;
	CPitcher Pitcher;
	CFileList PitcherList;
	double PitchSignType = 0;
	int StanceCursor;
	string ResultText;
	int Exception_SaveCustomBall = 0;
	int idxReplay = 0;
	double Proficiency = 0;
	int Frequency = 0;

	double Replay_ballnowframe;
	double Replay_batnowframe;
	double Replay_collisionnowframe;

public:
	void Initialize(void);
	void Update(void);
	void Render(void);
	void Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods);
	void Mouse(GLFWwindow* window, int button, int action, int mods);

};
