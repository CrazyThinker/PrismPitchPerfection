#include "GeometryBuffer.h"

CGeometryBuffer::CGeometryBuffer(void)
{
	this->vertex_array = 0;
	this->vertex_buffer = 0;
	this->index_buffer = 0;

}


CGeometryBuffer::~CGeometryBuffer(void)
{
}


void CGeometryBuffer::InitBuffer(std::vector<vertex> v_Vertex, bool IsOrder, GLenum mode, GLuint program)
{
	int i, n;
	std::vector<uint> indices;

	this->mode = mode;
	this->program = program;

	n = v_Vertex.size();
	if (IsOrder)
	{
		switch (mode)
		{
		// 1����
		case GL_POINTS:
			for (i = 0; i < n; i++)
			{
				indices.push_back(i);
			}
			break;

		// 2����
		case GL_LINE_STRIP: case GL_LINE_LOOP: case GL_LINES:
			for (i = 0; i < n; i++)
			{
				indices.push_back(i);
			}
			break;

		// 3����
		case GL_TRIANGLES: // n�� 3�� ���������
			for (i = 0; i < n; i+=3)
			{
				indices.push_back(i);
				indices.push_back(i + 1);
				indices.push_back(i + 2);
			}
			for (i = n - 3; i >= 0; i -= 3)
			{
				indices.push_back(i);
				indices.push_back(i + 2);
				indices.push_back(i + 1);
			}
			break;

		case GL_TRIANGLE_STRIP:
			for (i = 0; i < n - 3; i++)
			{
				indices.push_back(i);
				indices.push_back(i + 1);
				indices.push_back(i + 2);
			}
			for (i = n - 3; i >= 0; i--)
			{
				indices.push_back(i);
				indices.push_back(i + 2);
				indices.push_back(i + 1);
			}
			break;

		case GL_TRIANGLE_FAN:
			for (i = 1; i < n - 1; i++)
			{
				indices.push_back(0);
				indices.push_back(i);
				indices.push_back(i + 1);
			}
			for (i = n - 2; i >= 1; i--)
			{
				indices.push_back(0);
				indices.push_back(i + 1);
				indices.push_back(i);
			}
			break;
		}
	}
	else
	{
	}
	this->size = indices.size();

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// generation of vertex buffer
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * v_Vertex.size(), &v_Vertex[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array)	glDeleteVertexArrays(1, &vertex_array);
	vertex_array = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array) { printf("%s(): failed to create vertex aray\n", __func__); return; }

}

void CGeometryBuffer::InitBuffer(std::vector<vertex> v_Vertex, std::vector<uint> indices, GLenum mode, GLuint program)
{
	int n;

	this->mode = mode;
	this->program = program;
	this->size = indices.size();

	n = v_Vertex.size();

	// clear and create new buffers
	if (vertex_buffer)	glDeleteBuffers(1, &vertex_buffer);	vertex_buffer = 0;
	if (index_buffer)	glDeleteBuffers(1, &index_buffer);	index_buffer = 0;

	// generation of vertex buffer
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertex) * v_Vertex.size(), &v_Vertex[0], GL_STATIC_DRAW);

	// geneation of index buffer
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(uint) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	if (vertex_array)	glDeleteVertexArrays(1, &vertex_array);
	vertex_array = cg_create_vertex_array(vertex_buffer, index_buffer);
	if (!vertex_array) { printf("%s(): failed to create vertex aray\n", __func__); return; }
}

void CGeometryBuffer::Draw(mat4 model_matrix)
{
	glUseProgram(program);
	glBindVertexArray(vertex_array);

	glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"), 1, GL_TRUE, model_matrix);
	glDrawElements(mode, size, GL_UNSIGNED_INT, nullptr);
}
