#include "DTO.h"


CBallPropertyDTO::CBallPropertyDTO(void)
{
}


CBallPropertyDTO::~CBallPropertyDTO(void)
{
}


void CBallPropertyDTO::SetBallProperty(CBallProperty data)
{
	strcpy(name, data.name);
	frequency = data.frequency;
	proficiency = data.frequency;
	size = data.size;
	mass = data.mass;
	frame = data.frame;
	g = data.g;
	C_d = data.C_d;
	C_l = data.C_l;
	e_v = data.e_v;
	e_g = data.e_g;
}


CBallProperty CBallPropertyDTO::GetBallProperty(void)
{
	CBallProperty data;

	strcpy(data.name, name);
	data.frequency = frequency;
	data.proficiency = frequency;
	data.size = size;
	data.mass = mass;
	data.frame = frame;
	data.g = g;
	data.C_d = C_d;
	data.C_l = C_l;
	data.e_v = e_v;
	data.e_g = e_g;

	return data;
}


string CBallPropertyDTO::Serialize(void)
{
	char szText[1024];

	sprintf(szText, "%s %d %g %g %g %g %g %g %g %g %g", name, frequency, size, mass, frame, g, C_d, C_l, e_v, e_g);

	return szText;
}


void CBallPropertyDTO::Deserialize(string String)
{
	sscanf(String.c_str(), "%s%d%g%g%g%g%g%g%g%g%g", name, &frequency, &size, &mass, &frame, &g, &C_d, &C_l, &e_v, &e_g);
}


CBallFactorDTO::CBallFactorDTO(void)
{
}


CBallFactorDTO::~CBallFactorDTO(void)
{
}


void CBallFactorDTO::SetBallFactor(CBallFactor data)
{
	location = data.location;
	velocity = data.velocity;
	angle = data.angle;
	spin = data.spin;
	spin_euler = data.spin_euler;
	spin_angle = data.spin_angle;
}


CBallFactor CBallFactorDTO::GetBallFactor(void)
{
	CBallFactor data;

	data.location = location;
	data.velocity = velocity;
	data.angle = angle;
	data.spin = spin;
	data.spin_euler = spin_euler;
	data.spin_angle = spin_angle;

	return data;
}


string CBallFactorDTO::Serialize(void)
{
	char szText[1024];

	sprintf(szText, "%g %g %g %g %g %g %g %g %g %g %g %g %g", location.x, location.y, location.z, velocity.x, velocity.y, velocity.z, angle.x, angle.y, angle.z, spin, spin_euler.x, spin_euler.y, spin_angle);

	return szText;
}


void CBallFactorDTO::Deserialize(string String)
{
	sscanf(String.c_str(), "%g %g %g %g %g %g %g %g %g %g %g %g %g", &location.x, &location.y, &location.z, &velocity.x, &velocity.y, &velocity.z, &angle.x, &angle.y, &angle.z, &spin, &spin_euler.x, &spin_euler.y, &spin_angle);
}
