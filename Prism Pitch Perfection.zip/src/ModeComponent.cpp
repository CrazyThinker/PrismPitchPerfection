#include "ModeComponent.h"
#include "Utility.h"


CModeComponent::CModeComponent(void)
{
}

CModeComponent::~CModeComponent(void)
{
}

void CModeComponent::Update(void)
{
	cam.aspect = window_size.x / float(window_size.y);
	cam.projection_matrix = mat4::perspective(cam.fovy, cam.aspect, cam.dnear, cam.dfar);


	// update uniform variables in vertex/fragment shaders
	GLint uloc;
	uloc = glGetUniformLocation(Program, "view_matrix");			if (uloc > -1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam.view_matrix);
	uloc = glGetUniformLocation(Program, "projection_matrix");	if (uloc > -1) glUniformMatrix4fv(uloc, 1, GL_TRUE, cam.projection_matrix);
}


void CModeComponent::SetWindowSize(ivec2 window_size)
{
	this->window_size = window_size;
}


mat4 CModeComponent::GetMatrixTranslate(int x, int y, int width, int height)
{
	mat4 model_matrix, identity_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	mat4 translate_matrix = mat4(
		2.0f * height / window_size.x, 0.0f, 0.0f, -1.0f + 2.0f * y / window_size.x,
		0.0f, -(2.0f * width / window_size.y), 0.0f, -(-1.0f + 2.0f * x / window_size.y),
		0.0f, 0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 1.0f
	);

	return translate_matrix;
}


ivec2 CModeComponent::CalculateiVelocity(CBall& Ball, vec3 corLocation, ivec2 iVelocity, uint min_velocity_angle, int ball_framefps)
{
	CBall tmpBall1 = Ball, tmpBall2 = Ball;

	double Velocity = Ball.Track.Origin.velocity_length();
	tmpBall1.Track.Origin = tmpBall2.Track.Origin = Ball.Track.Origin;

	tmpBall1.Track.Origin.velocity = EulerAngle(iVelocity, min_velocity_angle) * Velocity;
	tmpBall1.ThrowBall(1.0f / ball_framefps, 0);

	iVelocity += ivec2(1, 1);
	tmpBall2.Track.Origin.velocity = EulerAngle(iVelocity, min_velocity_angle) * Velocity;
	tmpBall2.ThrowBall(1.0f / ball_framefps, 0);

	iVelocity.x += (int)((corLocation.x - tmpBall2.BallZone.location.x) / (tmpBall2.BallZone.location.x - tmpBall1.BallZone.location.x));
	iVelocity.y += (int)((corLocation.z - tmpBall2.BallZone.location.z) / (tmpBall2.BallZone.location.z - tmpBall1.BallZone.location.z));

	//printf("1: (%g, %g, %g)\n", tmpBall1.BallZone.location.x, tmpBall1.BallZone.location.y, tmpBall1.BallZone.location.z);
	//printf("2: (%g, %g, %g)\n", tmpBall2.BallZone.location.x, tmpBall2.BallZone.location.y, tmpBall2.BallZone.location.z);
	//printf("After (%d %d %d)\n\n", iVelocity.x, iVelocity.y, min_velocity_angle);

	return iVelocity;
}


tuple<ivec2, ivec2, ivec2> CModeComponent::CalculateDirection(CBall& Ball, vec3 StrikeZoneSize, uint min_velocity_angle, int ball_framefps)
{
	int i;
	CBall tmpBall;
	vec3 corTopLeft(-StrikeZoneSize.z, 0.0f, StrikeZoneSize.y); // (-0.215, 0, 0.9)
	vec3 corCenter(0.0f, 0.0f, (StrikeZoneSize.x + StrikeZoneSize.y) / 2);
	vec3 corBottomRight(StrikeZoneSize.z, 0.0f, StrikeZoneSize.x); // (0.215, 0, 0.35)
	tuple<ivec2, ivec2, ivec2> Result; // ������� TopLeft, Center, BottomRight

	tmpBall = Ball;
	get<0>(Result) = get<1>(Result) = get<2>(Result) = ivec2(min_velocity_angle * 3 / 2, min_velocity_angle / 3);

	for (i = 1; i <= 5; i++)
	{
		get<0>(Result) = CalculateiVelocity(tmpBall, corTopLeft, get<0>(Result), min_velocity_angle, ball_framefps); //TopLeft
		get<1>(Result) = CalculateiVelocity(tmpBall, corCenter, get<1>(Result), min_velocity_angle, ball_framefps); // Center
		get<2>(Result) = CalculateiVelocity(tmpBall, corBottomRight, get<2>(Result), min_velocity_angle, ball_framefps); // BottomRight
	}

	//printf("%d %d\n", get<1>(Result).x, get<1>(Result).y);

	return Result;
}
/*
void CPitcherBall::CalculateDirection(CBall& Ball, vec3 StrikeZoneSize, uint min_velocity_angle, int ball_framefps)
{
	int i, nBall = PitchBall.size() - 1;
	CBall tmpBall = Ball;
	tuple<ivec2, ivec2, ivec2> Result;

	for (i = 1; i <= nBall; i++)
	{
		tmpBall.Track.Origin.location = PitchBall[i].Origin.location;
		tmpBall.Track.Origin.velocity = dvec3(0, -PitchBall[i].Origin.velocity_length() * 1000.0f / 3600.0f, 0);
		tmpBall.Track.Origin.angle = PitchBall[i].Origin.angle;
		tmpBall.Track.Origin.spin_euler = PitchBall[i].Origin.spin_euler;
		tmpBall.Track.Origin.spin = PitchBall[i].Origin.spin / 60.0f * 2.0 * PI;

		Result = PitchBall[i].CalculateDirection(tmpBall, StrikeZoneSize, min_velocity_angle, ball_framefps);

		PitchBall[i].vTopLeft = get<0>(Result);
		PitchBall[i].vCenter = get<1>(Result);
		PitchBall[i].vBottomRight = get<2>(Result);
	}
}
*/



//*************************************
pair<std::vector<vertex>, std::vector<uint> > CModeComponent::Initialize_BaseBall_vertex(float thick) // BaseBall
{
	//vertex: position, color, texture
	std::vector<vertex> v = {}; // Origin
	std::vector<uint> indices;

	vec3 Color;
	int size, i;
	float t, ct, st, q, cq, sq;
	float x, y, z;
	dvec3 pos;

	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_longitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		for (uint i = 0; i <= max_latitude; i++)
		{
			q = PI * int(i) / float(max_latitude);// 0<q<PI		q=theta
			cq = cos(q);
			sq = sin(q);
			pos = dvec3(sq * ct, sq * st, cq);
			v.push_back({ vec3(pos.x, pos.y, pos.z), vec3(221 / 255.0f, 221 / 255.0f, 221 / 255.0f), vec2(0.0f,3.0f) });
		}
	}

	size = v.size();
	// �ǹ� ���
	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_longitude);// 0<t<2PI		t=phi
		// x = (1 / 13)(9 cos(a) - 4 cos(3a))
		// y = (1 / 13)(9 sin(a) + 4 sin(3a))
		// z = (12 / 13)cos(2a)
		x = (9.0f * cos(t) - 4.0f * cos(3 * t)) / 13.0f;
		y = (9.0f * sin(t) + 4.0f * sin(3 * t)) / 13.0f;
		z = cos(2 * t) * 12.0f / 13.0f;

		for (i = 0; i < size; i++)
		{
			if (abs(x - v[i].pos.x) <= thick && abs(y - v[i].pos.y) <= thick && abs(z - v[i].pos.z) <= thick)
			{
				v[i].norm = vec3(136.0f / 255.0f, 0.0f / 255.0f, 21.0f / 255.0f); // �ǹ信 �ش��ϴ� �κ�
			}
		}
	}


	// create buffers
	for (uint k = 0; k < max_longitude; k++)//Origin to sphere
	{
		for (uint i = 0; i < max_latitude; i++)
		{
			// think that k*max_longitude+i is already done
			//first triangle of square
			indices.push_back(k * (max_latitude + 1) + i);
			indices.push_back(k * (max_latitude + 1) + i + 1);
			indices.push_back((k + 1) * (max_latitude + 1) + i);
			//second triangle of squre
			indices.push_back((k + 1) * (max_latitude + 1) + i);
			indices.push_back(k * (max_latitude + 1) + i + 1);
			indices.push_back((k + 1) * (max_latitude + 1) + i + 1);
		}
	}

	return make_pair(v, indices);

}


void CModeComponent::Initialize_Vertex(void)
{
	float t, ct, st, x, y;

	std::vector<vertex> v_BaseBall = {}; // Origin
	std::vector<vertex> v_Ground = {}; // Origin
	std::vector<vertex> v_InfieldGround = {}; // Origin
	std::vector<vertex> v_3FeetLine = {}; // Origin
	std::vector<vertex> v_GrassLine = {}; // Origin
	std::vector<vertex> v_StrikeZone = {}; // Origin
	std::vector<vertex> v_LBatterZone = {}; // Origin
	std::vector<vertex> v_RBatterZone = {}; // Origin
	std::vector<vertex> v_BaseLine = {}; // Origin
	std::vector<vertex> v_HomePlate = {}; // Origin
	std::vector<vertex> v_1BasePlate = {}; // Origin
	std::vector<vertex> v_2BasePlate = {}; // Origin
	std::vector<vertex> v_3BasePlate = {}; // Origin
	std::vector<vertex> v_Circle = {}; // Origin
	std::vector<vertex> v_Donut = {}; // Origin
	std::vector<vertex> v_BallMovement = {}; // Origin
	std::vector<vertex> v_PitcherCursor = {}; // Origin
	std::vector<vertex> v_PitcherBar = {}; // Origin

	std::vector<uint> i_Donut;
	pair<std::vector<vertex>, std::vector<uint> > vi_BaseBall;

	// outline vertex
	v_InfieldGround.push_back({ vec3(0.0f, 0.215f - 1.293f,0.002f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_InfieldGround.push_back({ vec3(19.612f + 0.269f - 1.293f,19.397f + 0.269f,0.002f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_InfieldGround.push_back({ vec3(0.0f,39.332f - 1.293f,0.002f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_InfieldGround.push_back({ vec3(-19.612f - 0.269f + 1.293f,19.397f + 0.269f,0.002f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });

	v_3FeetLine.push_back({ vec3(0.6466f, -0.6466f,0.003f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_3FeetLine.push_back({ vec3(-0.6466f, 0.6466f,0.003f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_3FeetLine.push_back({ vec3(19.612f - 0.6466f,19.397f + 0.6466f,0.003f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_3FeetLine.push_back({ vec3(19.612f + 0.6466f,19.397f - 0.6466f,0.003f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });

	v_StrikeZone.push_back({ vec3(-StrikeZoneSize.z,0.0f,StrikeZoneSize.x), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_StrikeZone.push_back({ vec3(StrikeZoneSize.z,0.0f,StrikeZoneSize.x), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_StrikeZone.push_back({ vec3(StrikeZoneSize.z,0.0f,StrikeZoneSize.y), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_StrikeZone.push_back({ vec3(-StrikeZoneSize.z,0.0f,StrikeZoneSize.y), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });

	v_LBatterZone.push_back({ vec3(0.375f,-0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_LBatterZone.push_back({ vec3(1.595f,-0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_LBatterZone.push_back({ vec3(1.595f,0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_LBatterZone.push_back({ vec3(0.375f,0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });

	v_RBatterZone.push_back({ vec3(-0.375f,-0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_RBatterZone.push_back({ vec3(-1.595f,-0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_RBatterZone.push_back({ vec3(-1.595f,0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	v_RBatterZone.push_back({ vec3(-0.375f,0.91f,0.01f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });

	v_BaseLine.push_back({ vec3(1.115f,0.91f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_BaseLine.push_back({ vec3(19.612f + 0.269f,19.397f + 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_BaseLine.push_back({ vec3(0.0f,39.332f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_BaseLine.push_back({ vec3(-19.612f - 0.269f,19.397f + 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_BaseLine.push_back({ vec3(-1.115f,0.91f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });

	v_HomePlate.push_back({ vec3(0.0f,-0.215f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_HomePlate.push_back({ vec3(0.215f,0.0f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_HomePlate.push_back({ vec3(0.215f,0.215f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_HomePlate.push_back({ vec3(-0.215f,0.215f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_HomePlate.push_back({ vec3(-0.215f,0.0f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });

	v_1BasePlate.push_back({ vec3(19.612f,19.397f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_1BasePlate.push_back({ vec3(19.612f + 0.269f,19.397f + 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_1BasePlate.push_back({ vec3(19.612f,19.397f + 0.269f * 2,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_1BasePlate.push_back({ vec3(19.612f - 0.269f,19.397f + 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });

	v_2BasePlate.push_back({ vec3(0.0f,39.332f - 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_2BasePlate.push_back({ vec3(0.0f + 0.269f,39.332f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_2BasePlate.push_back({ vec3(0.0f,39.332f + 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_2BasePlate.push_back({ vec3(0.0f - 0.269f,39.332f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });

	v_3BasePlate.push_back({ vec3(-19.612f,19.397f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_3BasePlate.push_back({ vec3(-19.612f - 0.269f,19.397f + 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_3BasePlate.push_back({ vec3(-19.612f,19.397f + 0.269f * 2,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });
	v_3BasePlate.push_back({ vec3(-19.612f + 0.269f,19.397f + 0.269f,0.01f), vec3(219.0f / 255.0f, 219.0f / 255.0f, 219.0f / 255.0f), vec2(0.0f,3.0f) });

	v_BallMovement.push_back({ vec3(0, 0, 0), vec3(34.0f / 255.0f, 177.0f / 255.0f, 76.0f / 255.0f), vec2(0.0f,3.0f) });
	v_BallMovement.push_back({ vec3(1, 1, 1), vec3(34.0f / 255.0f, 177.0f / 255.0f, 76.0f / 255.0f), vec2(0.0f,3.0f) });

	vi_BaseBall = Initialize_BaseBall_vertex(0.12f);

	v_PitcherCursor.push_back({ vec3(0,0,1), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,2.0f) });
	v_PitcherCursor.push_back({ vec3(0.5,0.5,1), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,2.0f) });
	v_PitcherCursor.push_back({ vec3(1,0,1), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,2.0f) });

	v_PitcherBar.push_back({ vec3(0,0,1), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,2.0f) });
	v_PitcherBar.push_back({ vec3(0,1,1), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,2.0f) });
	v_PitcherBar.push_back({ vec3(1,1,1), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,2.0f) });
	v_PitcherBar.push_back({ vec3(1,0,1), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,2.0f) });

	v_Ground.push_back({ vec3(0.00f,-5.00f,0.00f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	for (uint k = max_longitude / 8; k <= max_longitude / 8 * 3; k++)
	{
		t = PI * 2.0f * k / float(max_longitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		v_Ground.push_back({ vec3(120.0f * ct, -5 + 120.0f * st,0.00f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) }); // ����ũ�� 120m
	}

	v_GrassLine.push_back({ vec3(0.00f,18.44f,0.001f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	for (uint k = 0; k <= 360 / 2; k++)
	{
		t = PI * 2.0f * k / float(360);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		x = ct * 28.96f;
		y = 18.44f + st * 28.96f;
		if (x >= 0 && x > y + 1.508f)
		{
			x = 19.948f / (1.0f - st / ct);
			y = (1.508f * st / ct + 18.44f) / (1.0f - st / ct);
		}
		else if (x < 0 && -x > y + 1.508f)
		{
			x = -19.948f / (1.0f + st / ct);
			y = (-1.508f * st / ct + 18.44f) / (1.0f + st / ct);
		}
		v_GrassLine.push_back({ vec3(x, y, 0.001f), vec3(1.0f, 1.0f, 1.0f), vec2(0.0f,3.0f) });
	}

	v_Circle.push_back({ vec3(0,0,0), vec3(1,1,1), vec2(0.0f,3.0f) });
	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_longitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		v_Circle.push_back({ vec3(ct,st,0), vec3(1,1,1), vec2(0.0f,3.0f) });
		v_Donut.push_back({ vec3(ct,st,0), vec3(1,1,1), vec2(0.0f,3.0f) });
	}
	for (uint k = 0; k <= max_longitude; k++) v_Donut.push_back({ v_Donut[k].pos * 0.75f, v_Donut[k].norm, v_Donut[k].tex });
	for (uint k = 0; k <= max_longitude - 1; k++)
	{
		i_Donut.push_back(k);
		i_Donut.push_back(k + 1);
		i_Donut.push_back(k + max_longitude + 1);

		i_Donut.push_back(k);
		i_Donut.push_back(k + max_longitude + 1);
		i_Donut.push_back(k + 1);

		i_Donut.push_back(k + max_longitude + 1);
		i_Donut.push_back(k + max_longitude + 2);
		i_Donut.push_back(k + 1);

		i_Donut.push_back(k + max_longitude + 1);
		i_Donut.push_back(k + 1);
		i_Donut.push_back(k + max_longitude + 2);

		i_Donut.push_back(k);
		i_Donut.push_back(k + 1);
		i_Donut.push_back(k + max_longitude + 2);

		i_Donut.push_back(k);
		i_Donut.push_back(k + max_longitude + 2);
		i_Donut.push_back(k + 1);

		i_Donut.push_back(k + max_longitude + 1);
		i_Donut.push_back(k + max_longitude + 2);
		i_Donut.push_back(k);

		i_Donut.push_back(k + max_longitude + 1);
		i_Donut.push_back(k);
		i_Donut.push_back(k + max_longitude + 2);
	}

	vertex_Ground.InitBuffer(v_Ground, true, GL_TRIANGLE_FAN, Program);
	vertex_InfieldGround.InitBuffer(v_InfieldGround, true, GL_TRIANGLE_FAN, Program);
	vertex_3FeetLine.InitBuffer(v_3FeetLine, true, GL_TRIANGLE_FAN, Program);
	vertex_GrassLine.InitBuffer(v_GrassLine, true, GL_TRIANGLE_FAN, Program);
	vertex_StrikeZone.InitBuffer(v_StrikeZone, true, GL_LINE_LOOP, Program);
	vertex_LBatterZone.InitBuffer(v_LBatterZone, true, GL_LINE_LOOP, Program);
	vertex_RBatterZone.InitBuffer(v_RBatterZone, true, GL_LINE_LOOP, Program);
	vertex_BaseLine.InitBuffer(v_BaseLine, true, GL_LINE_STRIP, Program);
	vertex_HomePlate.InitBuffer(v_HomePlate, true, GL_TRIANGLE_FAN, Program);
	vertex_1BasePlate.InitBuffer(v_1BasePlate, true, GL_TRIANGLE_FAN, Program);
	vertex_2BasePlate.InitBuffer(v_2BasePlate, true, GL_TRIANGLE_FAN, Program);
	vertex_3BasePlate.InitBuffer(v_3BasePlate, true, GL_TRIANGLE_FAN, Program);
	vertex_Circle.InitBuffer(v_Circle, true, GL_TRIANGLE_FAN, Program);
	vertex_Donut.InitBuffer(v_Donut, i_Donut, GL_TRIANGLES, Program);
	vertex_BallMovement.InitBuffer(v_BallMovement, true, GL_LINE_STRIP, Program);
	vertex_BaseBall.InitBuffer(vi_BaseBall.first, vi_BaseBall.second, GL_TRIANGLE_FAN, Program);
	vertex_PitcherCursor.InitBuffer(v_PitcherCursor, true, GL_TRIANGLE_FAN, Program);
	vertex_PitcherBar.InitBuffer(v_PitcherBar, true, GL_TRIANGLE_FAN, Program);

}


void CModeComponent::Initialize_Bat(void)
{
	CBatInfo nullBat, Bat1, ThickBat;

	Bat1.CreateBat1(Program, 0.035f, 0.83f, 0.152f);
	ThickBat.CreateBat1(Program, 0.035f * 1.7f, 0.83f * 1.1f, 0.152f * 1.1f);

	BatInfo.push_back(nullBat);
	BatInfo.push_back(Bat1);
	BatInfo.push_back(ThickBat);
}


// camera init
void CModeComponent::Initialize_Camera(int Type)
{
	CCamera camLPitcher1, camRPitcher1, camLPitcher2, camRPitcher2, camCatcher, camLBatter, camRBatter, camSky;

	// ������ ����
	camLPitcher1.eye = vec3(1.9f, 57.75f, 3.45f);
	camLPitcher1.at = vec3(0.375f, 10.0f, 1.08f);
	camLPitcher1.up = vec3(0, 0.0f, 1.0f);
	camLPitcher1.fovy *= 0.1f;
	camLPitcher1.view_matrix = mat4::look_at(camLPitcher1.eye, camLPitcher1.at, camLPitcher1.up);

	// ������ ����
	camRPitcher1.eye = vec3(-1.9f, 57.75f, 3.45f);
	camRPitcher1.at = vec3(-0.375f, 10.0f, 1.08f);
	camRPitcher1.up = vec3(0, 0.0f, 1.0f);
	camRPitcher1.fovy *= 0.1f;
	camRPitcher1.view_matrix = mat4::look_at(camRPitcher1.eye, camRPitcher1.at, camRPitcher1.up);
	/*
	// ������ ����
	camLPitcher2.eye = vec3(2.05f, 62.0f, 7.75f);
	camLPitcher2.at = vec3(0.375f, 10.0f, 1.3f);
	camLPitcher2.up = vec3(0, 0.0f, 1.0f);
	camLPitcher2.fovy *= 0.1f;
	camLPitcher2.view_matrix = mat4::look_at(camLPitcher2.eye, camLPitcher2.at, camLPitcher2.up);

	// ������ ����
	camRPitcher2.eye = vec3(-2.05f, 62.0f, 7.75f);
	camRPitcher2.at = vec3(-0.375f, 10.0f, 1.3f);
	camRPitcher2.up = vec3(0, 0.0f, 1.0f);
	camRPitcher2.fovy *= 0.1f;
	camRPitcher2.view_matrix = mat4::look_at(camRPitcher2.eye, camRPitcher2.at, camRPitcher2.up);
	*/

	// ������ ����
	camLPitcher2.eye = vec3(2.05f, 68.0f, 7.9f);
	camLPitcher2.at = vec3(0.345f, 10.0f, 1.21f);
	camLPitcher2.up = vec3(0, 0.0f, 1.0f);
	camLPitcher2.fovy *= 0.1f;
	camLPitcher2.view_matrix = mat4::look_at(camLPitcher2.eye, camLPitcher2.at, camLPitcher2.up);

	// ������ ����
	camRPitcher2.eye = vec3(-2.05f, 68.0f, 7.9f);
	camRPitcher2.at = vec3(-0.345f, 10.0f, 1.21f);
	camRPitcher2.up = vec3(0, 0.0f, 1.0f);
	camRPitcher2.fovy *= 0.1f;
	camRPitcher2.view_matrix = mat4::look_at(camRPitcher2.eye, camRPitcher2.at, camRPitcher2.up);

	// ���� ����
	camCatcher.eye = vec3(0, -3.3f / 3 * 2, (StrikeZoneSize.x + StrikeZoneSize.y) / 2.0f + 0.15f);
	camCatcher.at = vec3(0, 20.0f, 0.5f);
	camCatcher.up = vec3(0, 0.0f, 1.0f);
	camCatcher.view_matrix = mat4::look_at(camCatcher.eye, camCatcher.at, camCatcher.up);

	// ��Ÿ�� ����
	camLBatter.eye = vec3(1.63f, -1.9f, 1.1f);
	camLBatter.at = vec3(-1.75f, 20.0f, 0.5f);
	camLBatter.up = vec3(0, 0.0f, 1.0f);
	camLBatter.view_matrix = mat4::look_at(camLBatter.eye, camLBatter.at, camLBatter.up);

	// ��Ÿ�� ����
	camRBatter.eye = vec3(-1.63f, -1.9f, 1.1f);
	camRBatter.at = vec3(1.75f, 20.0f, 0.5f);
	camRBatter.up = vec3(0, 0.0f, 1.0f);
	camRBatter.view_matrix = mat4::look_at(camRBatter.eye, camRBatter.at, camRBatter.up);

	// �ϴ� ����
	camSky.eye = vec3(0, -5.4f, 4.5f);
	camSky.at = vec3(0, 20.0f, -6.5f);
	camSky.up = vec3(0, 0.5f, 0.9f);
	camSky.view_matrix = mat4::look_at(camSky.eye, camSky.at, camSky.up);

	camlist.clear();
	nowcam = 0;
	switch (Type)
	{
	case 10: // Custom Mode
		camlist.push_back(camCatcher);
		//camlist.push_back(camLPitcher1);
		camlist.push_back(camLPitcher2);
		//camlist.push_back(camRPitcher1);
		camlist.push_back(camRPitcher2);
		camlist.push_back(camSky);
		camlist.push_back(camCatcher);
		camlist.push_back(camLBatter);
		camlist.push_back(camRBatter);
		break;

	case 20: // Batter Mode
		camlist.push_back(camCatcher);
		camlist.push_back(camLBatter);
		camlist.push_back(camRBatter);
		camlist.push_back(camSky);
		//camlist.push_back(camLPitcher1);
		camlist.push_back(camLPitcher2);
		//camlist.push_back(camRPitcher1);
		camlist.push_back(camRPitcher2);
		break;

	case 30: // Pitcher Mode
		camlist.push_back(camCatcher);
		//camlist.push_back(camLPitcher1);
		camlist.push_back(camLPitcher2);
		//camlist.push_back(camRPitcher1);
		camlist.push_back(camRPitcher2);
		break;
	}
	cam = camlist[0];
}


void CModeComponent::Camera_Prev(void)
{
	nowcam = (nowcam - 1 + camlist.size()) % camlist.size();
	cam = camlist[nowcam];
}


void CModeComponent::Camera_Next(void)
{
	nowcam = (nowcam + 1 + camlist.size()) % camlist.size();
	cam = camlist[nowcam];
}

void CModeComponent::Camera_Home(void)
{
	cam = camlist[nowcam];
}


void CModeComponent::ClearSchedule(void)
{
	Schedule.clear();
}


void CModeComponent::SetSchedule(CBallTrace& Track, int n, double nowframe, int Type, double SlowMode)
{
	list<pair<double, int> >::iterator idx, idxNext;
	pair<double, int> tmpSchedule;
	int i;
	double beforeframe = Track.Property.frame;
	Track.Property.frame /= SlowMode;

	if (Schedule.size() == 0) // �������� �ƿ� ����������
	{
		for (i = 0; i < n; i++) Schedule.push_back(make_pair(nowframe + i * Track.Property.frame, Type));
	}
	else if (Schedule.back().first <= nowframe) // �ڿ� ���� �������
	{
		for (i = 0; i < n; i++) Schedule.push_back(make_pair(nowframe + i * Track.Property.frame, Type));
	}
	else if (Schedule.front().first >= nowframe + (n - 1) * Track.Property.frame) // �տ� ���� �������
	{
		for (i = n - 1; i >= 0; i--) Schedule.push_front(make_pair(nowframe + i * Track.Property.frame, Type));
	}
	else // ���̻��� �������
	{
		idx = Schedule.begin();
		idxNext = idx;
		idxNext++;
		for (i = 0; i < n; i++)
		{
			tmpSchedule = make_pair(nowframe + i * Track.Property.frame, Type);
			while (idxNext != Schedule.end())
			{
				if (idxNext->first >= tmpSchedule.first) break;
				idx = idxNext;
				idxNext++;
			}
			Schedule.insert(idxNext, tmpSchedule);
		}
	}

	Track.Property.frame = beforeframe;

}


void CModeComponent::SetSchedule(CBall& BaseBall, int Type, double SlowMode) // 0: �� ����ħ, 1: ��Ʈ�Ǳ�������, 2: ���� ����
{
	if (Type == 0) // �� ����ħ
	{
		SetSchedule(BaseBall.Track, BaseBall.Track.Track.size(), BaseBall.nowframe, 1, SlowMode);
	}
	else if (Type == 1) // ��Ʈ�Ǳ�������
	{
		SetSchedule(BaseBall.Track, BaseBall.Track.idxTrackMovement, BaseBall.nowframe, 1, SlowMode);
	}
	else if (Type == 2) // ���� ����
	{
		SetSchedule(BaseBall.TrackCollision, BaseBall.TrackCollision.Track.size(), BaseBall.nowframe, 2, 1.0f);
	}

}


void CModeComponent::SetSchedule(CHitterBat& Bat)
{
	SetSchedule(Bat.Track, Bat.Track.Track.size(), Bat.nowframe, 11, 1.0f);
}


void CModeComponent::SetSchedule(double frame, int Type)
{
	list<pair<double, int> >::iterator idx, idxNext;

	if (Schedule.size() == 0)
	{
		Schedule.push_back(make_pair(frame, Type));
	}
	else if (Schedule.front().first >= frame)
	{
		Schedule.push_front(make_pair(frame, Type));
	}
	else
	{
		idx = Schedule.begin();
		idxNext = idx;
		idxNext++;
		while (idxNext != Schedule.end())
		{
			if (idxNext->first >= frame) break;
			idx = idxNext;
			idxNext++;
		}

		Schedule.insert(idxNext, make_pair(frame, Type));
	}
}


int CModeComponent::GetSchedule(double nowframe)
{
	int Result = 0;

	if (nowframe == 0) nowframe = t;

	if (!Schedule.empty() && Schedule.front().first <= nowframe)
	{
		Result = Schedule.front().second;
		Schedule.pop_front();
	}

	return Result;
}


void CModeComponent::RemoveSchedule(int Type)
{
	if (Schedule.empty()) return;
	list<pair<double, int> >::iterator idx, idxNext;

	idxNext = Schedule.begin();
	while (idxNext != Schedule.end())
	{
		idx = idxNext;
		if (idx->second == Type) Schedule.erase(idx);
		idxNext++;
	}
}


bool CModeComponent::EmptySchedule(void)
{
	return Schedule.empty();
}



void render_text(std::string text, GLint x, GLint y, GLfloat scale, vec4 color, GLfloat dpi_scale = 1.0f);
// text ���
void CModeComponent::Render_Text(string text, GLint x, GLint y, GLfloat scale, vec4 color, GLfloat dpi_scale)
{
	render_text(text, x, y, scale, color, dpi_scale);
}


// BaseBall�� ���
void CModeComponent::Render_BaseBall(CBall& BaseBall, bool OnlySpin)
{
	CBallFactor Factor;

	if (OnlySpin) Factor = BaseBall.Track.Origin;
	else if (BaseBall.balltype == 3 || BaseBall.balltype == 4) Factor = BaseBall.TrackCollision[BaseBall.idxTrackCollision];
	else if (BaseBall.idxTrack == -1) Factor = BaseBall.Track.Origin;
	else Factor = BaseBall.Track[BaseBall.idxTrack];

	if (Factor.location == dvec3(0, 0, 0)) return;

	mat4 rotation_matrix = GetRotationMatrix(dvec3(Factor.spin_angle, Factor.spin_euler.y - PI / 2, Factor.spin_euler.x));
	mat4 rotation_matrix_angle = GetRotationMatrix(dvec3(Factor.angle.x, Factor.angle.y, Factor.angle.z));

	mat4 model_matrix;
	mat4 scale_matrix = mat4::scale(BaseBall.Track.Property.size, BaseBall.Track.Property.size, BaseBall.Track.Property.size);
	//if (BaseBall.balltype == 4) scale_matrix = mat4::scale(BaseBall.Track.Ball_size * 1.5, BaseBall.Track.Ball_size * 1.5, BaseBall.Track.Ball_size * 1.5);
	//mat4 scale_matrix = mat4::scale(BaseBall.Track.Ball_size * 5, BaseBall.Track.Ball_size * 5, BaseBall.Track.Ball_size * 5);

	mat4 translate_matrix =
	{
		1, 0, 0, (float)Factor.location.x,
		0, 1, 0, (float)Factor.location.y,
		0, 0, 1, (float)Factor.location.z,
		0, 0, 0, 1
	};

	mat4 revolution_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	model_matrix = revolution_matrix * translate_matrix * rotation_matrix * rotation_matrix_angle * scale_matrix;

	vertex_BaseBall.Draw(model_matrix);
	//printf("%g %g %g\n", Factor.spin_angle, Factor.spin_euler.x - PI / 2, Factor.spin_euler.y);
}


// ��Ʈ����ũ���� ǥ�õ� �� ���
void CModeComponent::Render_BallZone(CBall& BaseBall, int mode)
{
	if (BaseBall.BallZone.location == dvec3(0, 0, 0)) return;
	GLuint uloc;
	// ���� ȸ��
	float cx, sx, cy, sy, cz, sz;
	cx = cos(BaseBall.BallZone.angle.x); sx = sin(BaseBall.BallZone.angle.x);
	cy = cos(BaseBall.BallZone.angle.y); sy = sin(BaseBall.BallZone.angle.y);
	cz = cos(BaseBall.BallZone.angle.z); sz = sin(BaseBall.BallZone.angle.z);

	mat4 model_matrix, rotation_matrix = GetRotationMatrix(dvec3(PI / 2.0f, 0, 0)), rotation_matrix_angle;

	mat4 scale_matrix = mat4::scale(BaseBall.Track.Property.size, BaseBall.Track.Property.size, BaseBall.Track.Property.size); // ���� ũ��� ��ȭ�� ����

	mat4 translate_matrix =
	{
		1, 0, 0, (float)BaseBall.BallZone.location.x,
		0, 1, 0, (float)BaseBall.BallZone.location.y,
		0, 0, 1, (float)BaseBall.BallZone.location.z,
		0, 0, 0, 1
	};

	mat4 revolution_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	model_matrix = revolution_matrix * translate_matrix * rotation_matrix * scale_matrix;

	switch (mode)
	{
	case 0: // Ball
		model_matrix = revolution_matrix * translate_matrix * rotation_matrix * scale_matrix;

		uloc = glGetUniformLocation(Program, "b_stzoneborder"); glUniform1i(uloc, 1);
		vertex_Donut.Draw(model_matrix);
		uloc = glGetUniformLocation(Program, "b_stzoneborder"); glUniform1i(uloc, 0);
		break;

	case 1: // Strike
		model_matrix = revolution_matrix * translate_matrix * rotation_matrix * scale_matrix;

		uloc = glGetUniformLocation(Program, "b_stzoneborder"); glUniform1i(uloc, 1);
		vertex_Donut.Draw(model_matrix);
		uloc = glGetUniformLocation(Program, "b_stzoneborder"); glUniform1i(uloc, 0);

		scale_matrix = mat4::scale(0.75f, 0.75f, 0.75f);
		model_matrix *= scale_matrix;
		vertex_Circle.Draw(model_matrix);
		break;

	case 2: // BaseBall
		rotation_matrix = GetRotationMatrix(dvec3(BaseBall.BallZone.spin_angle, BaseBall.BallZone.spin_euler.y - PI / 2, BaseBall.BallZone.spin_euler.x));
		rotation_matrix_angle = GetRotationMatrix(dvec3(BaseBall.BallZone.angle.x, BaseBall.BallZone.angle.y, BaseBall.BallZone.angle.z));
		model_matrix = revolution_matrix * translate_matrix * rotation_matrix * rotation_matrix_angle * scale_matrix;

		vertex_BaseBall.Draw(model_matrix);
		break;

	}
}

// ���� ���̵� ���
void CModeComponent::Render_BattingGuide(CBall& BaseBall)
{
	if (BaseBall.Track[BaseBall.idxTrack].location == dvec3(0, 0, 0) || BaseBall.Track[BaseBall.idxTrack].location.y < 0) return;
	double scale = 1.0f;
	if (BaseBall.idxTrack > 0) scale = BaseBall.Track[BaseBall.idxTrack].location.y / 2.5f + 1;
	GLuint uloc;

	mat4 model_matrix, rotation_matrix = GetRotationMatrix(dvec3(PI / 2.0f, 0, 0));
	mat4 scale_matrix = mat4::scale(BaseBall.Track.Property.size, BaseBall.Track.Property.size, BaseBall.Track.Property.size); // ���� ũ��� ��ȭ�� ����

	mat4 translate_matrix =
	{
		1, 0, 0, (float)BaseBall.BallZone.location.x,
		0, 1, 0, (float)BaseBall.BallZone.location.y,
		0, 0, 1, (float)BaseBall.BallZone.location.z,
		0, 0, 0, 1
	};

	mat4 revolution_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	model_matrix = revolution_matrix * translate_matrix * rotation_matrix * scale_matrix;
	model_matrix *= mat4::scale(scale, scale, scale);

	uloc = glGetUniformLocation(Program, "b_stzoneborder"); glUniform1i(uloc, 1);
	vertex_Donut.Draw(model_matrix);
	uloc = glGetUniformLocation(Program, "b_stzoneborder"); glUniform1i(uloc, 0);
}


// Bat�� ���
void CModeComponent::Render_Bat(CHitterBat& Bat, bool Preview)
{
	CBallFactor Factor;

	if (Bat.Type == 0) Factor = Bat.Track.Origin;
	else Factor = Bat.Track[Bat.idxTrack];

	if (Factor.location == dvec3(0, 0, 0)) return;

	uint uloc;
	mat4 model_matrix;
	mat4 rotation_matrix = GetRotationMatrix(dvec3(Factor.spin_angle, Factor.spin_euler.y - PI / 2, Factor.spin_euler.x));
	mat4 rotation_matrix_angle = GetRotationMatrix(dvec3(Factor.angle.x, Factor.angle.y, Factor.angle.z));

	if (Preview)
	{
		uloc = glGetUniformLocation(Program, "b_preview"); glUniform1i(uloc, 1);
		rotation_matrix = GetRotationMatrix(dvec3(-PI / 2, Factor.spin_euler.y - PI / 2, Factor.spin_euler.x));
	}

	mat4 translate_matrix =
	{
		1, 0, 0, (float)Factor.location.x,
		0, 1, 0, (float)Factor.location.y,
		0, 0, 1, (float)Factor.location.z,
		0, 0, 0, 1
	};
	mat4 revolution_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	model_matrix = revolution_matrix * translate_matrix * rotation_matrix * rotation_matrix_angle;

	// bind vertex array object
	if (Preview) BatInfo[Bat.BatType].vertex_Preview.Draw(model_matrix);
	else BatInfo[Bat.BatType].vertex_Bat.Draw(model_matrix);

	uloc = glGetUniformLocation(Program, "b_preview"); glUniform1i(uloc, 0);

}

// ����� ���
void CModeComponent::Render_Stadium(bool b_StrikeZone)
{
	GLint uloc;
	// update the outline
	mat4 model_matrix, scale_matrix, translate_matrix, identity_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	////////// �߱��� ���
	uloc = glGetUniformLocation(Program, "b_grass");	if (uloc > -1) glUniform1i(uloc, 1);
	vertex_Ground.Draw(identity_matrix);
	////////// ���ʵ� ���
	vertex_InfieldGround.Draw(identity_matrix);
	uloc = glGetUniformLocation(Program, "b_grass");	if (uloc > -1) glUniform1i(uloc, 0);
	////////// �׶󽺶��� ���
	uloc = glGetUniformLocation(Program, "b_mound");	if (uloc > -1) glUniform1i(uloc, 1);
	vertex_GrassLine.Draw(identity_matrix);
	////////// 3��Ʈ���� ���
	vertex_3FeetLine.Draw(identity_matrix);
	translate_matrix =
	{
		-1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	vertex_3FeetLine.Draw(translate_matrix);
	////////// ����� ���
	////////// 1. Ȩ����� ���
	scale_matrix = mat4::scale(3, 3, 3);
	translate_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0.003,
		0, 0, 0, 1
	};
	model_matrix = translate_matrix * scale_matrix;
	vertex_Circle.Draw(model_matrix);
	////////// 2. ���� ����� ���
	scale_matrix = mat4::scale(2.74f, 2.74f, 2.74f);
	translate_matrix[3] = 0.0f, translate_matrix[7] = 18.44f;
	model_matrix = translate_matrix * scale_matrix;
	vertex_Circle.Draw(model_matrix);
	////////// 3. 1�� ����� ���
	translate_matrix[3] = 19.612f, translate_matrix[7] = 19.397f;
	model_matrix = translate_matrix * scale_matrix;
	vertex_Circle.Draw(model_matrix);
	////////// 4. 2�� ����� ���
	translate_matrix[3] = 0.0f, translate_matrix[7] = 39.332f;
	model_matrix = translate_matrix * scale_matrix;
	vertex_Circle.Draw(model_matrix);
	////////// 5. 3�� ����� ���
	translate_matrix[3] = -19.612f, translate_matrix[7] = 19.397f;
	model_matrix = translate_matrix * scale_matrix;
	vertex_Circle.Draw(model_matrix);
	uloc = glGetUniformLocation(Program, "b_mound");	if (uloc > -1) glUniform1i(uloc, 0);
	////////// ��Ʈ����ũ�� ���
	if (b_StrikeZone) vertex_StrikeZone.Draw(identity_matrix);
	////////// ��Ÿ�� ���
	vertex_LBatterZone.Draw(identity_matrix);
	////////// ��Ÿ�� ���
	vertex_RBatterZone.Draw(identity_matrix);
	////////// ���̽����� ���
	vertex_BaseLine.Draw(identity_matrix);
	////////// Ȩ�÷���Ʈ ���
	vertex_HomePlate.Draw(identity_matrix);
	////////// 1�� ���̽� ���
	vertex_1BasePlate.Draw(identity_matrix);
	////////// 2�� ���̽� ���
	vertex_2BasePlate.Draw(identity_matrix);
	////////// 3�� ���̽� ���
	vertex_3BasePlate.Draw(identity_matrix);

}


// �� ���
void CModeComponent::Render_Line(dvec3 From, dvec3 To)
{
	dvec3 Distance = To - From;

	mat4 model_matrix;
	mat4 identity_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	mat4 scale_matrix = mat4::scale(Distance.x, Distance.y, Distance.z);
	mat4 translate_matrix =
	{
		1, 0, 0, (float)From.x,
		0, 1, 0, (float)From.y,
		0, 0, 1, (float)From.z,
		0, 0, 0, 1
	};

	model_matrix = identity_matrix * translate_matrix * scale_matrix;

	vertex_BallMovement.Draw(model_matrix);

}


// ���� ȸ���� ���
void CModeComponent::Render_SpinAxis(CBall& BaseBall, dvec3 axis)
{
	double r = BaseBall.Track.Property.size * 2.0f;

	axis = axis.normalize() * r;
	Render_Line(BaseBall.Track.Origin.location - axis, BaseBall.Track.Origin.location + axis);
	Render_Line(BaseBall.BallZone.location - axis, BaseBall.BallZone.location + axis);
}


// ���� ȸ���� ���
void CModeComponent::Render_SpinAxis(CBall& BaseBall, ivec2 axis)
{
	Render_SpinAxis(BaseBall, EulerAngle(axis, min_spin_angle));
}


// ���� �����Ʈ ���
void CModeComponent::Render_BallMovement(CBall& BaseBall)
{
	int i, n, root_curvature;
	CBallTrace* Track;
	uint uloc;

	if (BaseBall.balltype < 3)
	{
		Track = &BaseBall.Track;

		n = BaseBall.Track.idxTrackMovement - 1, root_curvature = (n + 1) / root_division;
		if (root_curvature == 0) root_curvature = 1;
	}
	else
	{
		Track = &BaseBall.TrackCollision;

		n = BaseBall.idxTrackCollision - 1, root_curvature = 1;

		uloc = glGetUniformLocation(Program, "b_modeball"); glUniform1i(uloc, 5);
	}
	if (n == 0) return;

	uloc = glGetUniformLocation(Program, "b_guideline");	if (uloc > -1) glUniform1i(uloc, 1);

	for (i = root_curvature; i <= n; i += root_curvature)
	{
		////////// ���� �����Ʈ ���
		Render_Line((*Track)[i - root_curvature].location, (*Track)[i].location);
	}
	if (i - root_curvature != n) Render_Line((*Track)[i - root_curvature].location, (*Track)[n].location);

	uloc = glGetUniformLocation(Program, "b_guideline");	if (uloc > -1) glUniform1i(uloc, 0);

	if (BaseBall.balltype == 3 || BaseBall.balltype == 4)
	{
		uloc = glGetUniformLocation(Program, "b_modeball"); glUniform1i(uloc, 0);
	}

}


// ��Ī�ӽ� ���
void CModeComponent::Render_PitchSign(double PitchSignType)
{
	GLint uloc;
	vec3 location(0.0f, 20.0f, 5.0f);

	mat4 identity_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	mat4 model_matrix;

	mat4 scale_matrix = mat4::scale(0.5f, 0.5f, 0.5f);
	mat4 rotation_matrix = GetRotationMatrix(dvec3(PI / 2.0f, 0, 0));

	mat4 translate_matrix =
	{
		1, 0, 0, location.x,
		0, 1, 0, location.y,
		0, 0, 1, location.z,
		0, 0, 0, 1
	};

	mat4 revolution_matrix =
	{
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	model_matrix = revolution_matrix * translate_matrix * rotation_matrix * scale_matrix;

	if (PitchSignType == 0)
	{
		uloc = glGetUniformLocation(Program, "b_pitchsign");	glUniform1i(uloc, 1);
		vertex_Circle.Draw(model_matrix);
		uloc = glGetUniformLocation(Program, "b_pitchsign");	glUniform1i(uloc, 0);
	}
	else
	{
		uloc = glGetUniformLocation(Program, "b_pitchsign");	glUniform1i(uloc, 2);
		vertex_Donut.Draw(model_matrix);
		model_matrix *= mat4::scale(PitchSignType * 0.75f, PitchSignType * 0.75f, PitchSignType * 0.75f);
		vertex_Circle.Draw(model_matrix);
		uloc = glGetUniformLocation(Program, "b_pitchsign");	glUniform1i(uloc, 0);
	}
}


void CModeComponent::Render_PitcherStrength(double Strength)
{
	int x;
	GLuint uloc;
	mat4 model_matrix;

	uloc = glGetUniformLocation(Program, "b_pitchergage");

	x = window_size.y - 185;

	if(Strength > 0.75f) glUniform1i(uloc, 2);
	else if(Strength > 0.25) glUniform1i(uloc, 3);
	else glUniform1i(uloc, 5);
	model_matrix = GetMatrixTranslate(x, 60, 5, 100 * Strength);
	vertex_PitcherBar.Draw(model_matrix);

	glUniform1i(uloc, 4);
	model_matrix = GetMatrixTranslate(x, 60 + 100 * Strength, 5, 100 * (1 - Strength));
	vertex_PitcherBar.Draw(model_matrix);

	glUniform1i(uloc, 0);
}


void CModeComponent::Render_StanceMode(int Cursor)
{
	int i, x, y, n = nStanceMode;
	float size;
	string name;
	char szText[104];

	for (i = 1; i <= nStanceMode; i++)
	{
		if (i == Cursor) size = 0.34f, x = 30, name = ">  ";
		else size = 0.3f, x = 40, name = "  ";
		name += StanceMode[i];
		y = window_size.y - 150 + 20 * i;
		Render_Text(name, x, y, size, vec4(0.1f, 0.1f, 0.2f, 1.0f));
	}
	sprintf(szText, "%d / %d", Cursor, n);
	Render_Text(szText, 70, window_size.y - 60, 0.3f, vec4(0.1f, 0.1f, 0.2f, 1.0f), 1.0f);

	glUseProgram(Program);
}


void CModeComponent::Render_PitchMinigame(int BoardCursor)
{
	int i, tmp;
	double Sum = 0;
	double Gage;
	GLuint uloc;
	mat4 model_matrix;

	uloc = glGetUniformLocation(Program, "b_pitchergage");

	glUniform1i(uloc, 1);
	if (BoardCursor == 10000) Gage = 100;
	else Gage = BoardCursor;
	model_matrix = GetMatrixTranslate(45, 50 - 10 + int(Gage * 3), 20, 20);
	vertex_PitcherCursor.Draw(model_matrix);
	model_matrix = GetMatrixTranslate(85, 50 - 10 + int(Gage * 3), -20, 20);
	vertex_PitcherCursor.Draw(model_matrix);

	for (i = 0; i <= 4; i++)
	{
		if (PitchMinigameWeight[i] == 0) continue;
		if (i == 0) glUniform1i(uloc, 5);
		else glUniform1i(uloc, i + 1);
		tmp = PitchMinigameWeight[i] * 3 + 1;
		if (tmp + Sum > 300) tmp--;
		model_matrix = GetMatrixTranslate(50, 50 + Sum, 30, tmp);
		vertex_PitcherBar.Draw(model_matrix);
		Sum += PitchMinigameWeight[i] * 3;
	}

	glUniform1i(uloc, 0);
}


void CModeComponent::Render_PitchboardProficiency(double proficiency, int x, int y)
{
	int pf = round(proficiency * 100);

	if (95 < pf)
	{
		Render_Text("(SS)", x, y, 0.30f, vec4(0.1f, 0.1f, 0.6f, 1.0f));
	}
	else if (90 < pf)
	{
		Render_Text("(S)", x, y, 0.30f, vec4(0.2f, 0.5f, 0.7f, 1.0f));
	}
	else if (85 < pf)
	{
		Render_Text("(A)", x, y, 0.30f, vec4(0.1f, 0.6f, 0.1f, 1.0f));
	}
	else if (80 < pf)
	{
		Render_Text("(B)", x, y, 0.30f, vec4(0.6f, 0.3f, 0.1f, 1.0f));
	}
	else if (70 < pf)
	{
		Render_Text("(C)", x, y, 0.30f, vec4(0.7f, 0.6f, 0.1f, 1.0f));
	}
	else
	{
		Render_Text("(F)", x, y, 0.30f, vec4(0.4f, 0.1f, 0.1f, 1.0f));
	}
}


void CModeComponent::Render_Pitchboard(CPitcher& Pitcher, int Cursor) // Use BallCursor
{
	int i, x, y, n = Pitcher.PitchBall.size() - 1;
	int tmpCursor;
	float size;
	string name;
	char szText[104];

	// 4������ ǥ��
	tmpCursor = (Cursor - 1) / 4;
	for (i = tmpCursor * 4 + 1; i <= (tmpCursor + 1) * 4 && i <= n; i++)
	{
		if (i == Cursor) size = 0.34f, x = 50, name = ">      ";
		else size = 0.3f, x = 70, name = "      ";
		name += Pitcher.PitchBall[i].Property.name;
		y = window_size.y - 150 + 20 * ((i + 3) % 4);
		Render_PitchboardProficiency(Pitcher.PitchBall[i].Property.proficiency, 70, y);
		Render_Text(name, x, y, size, vec4(0.1f, 0.1f, 0.2f, 1.0f));
	}
	sprintf(szText, "%d / %d Balls", Cursor, n);
	Render_Text(szText, 70, window_size.y - 60, 0.3f, vec4(0.1f, 0.1f, 0.2f, 1.0f), 1.0f);

	glUseProgram(Program);
}


void CModeComponent::Update_Ball(CBall& BaseBall)
{
	// flying ball�϶��� ball location�� update�Ѵ�
	if (BaseBall.balltype == 1)
	{
		BaseBall.idxTrack++;
		// ������ ��
		if (BaseBall.idxTrack >= BaseBall.Track.Track.size())
		{
			BaseBall.idxTrack--;
			BaseBall.BallZone_visible = true;
			BaseBall.balltype = 2;
		}
	}
	else if (BaseBall.balltype == 3)
	{
		BaseBall.idxTrackCollision++;
		// ������ ��
		if (BaseBall.idxTrackCollision >= BaseBall.TrackCollision.Track.size())
		{
			BaseBall.idxTrackCollision--;
			BaseBall.balltype = 4;
		}
	}
}


void CModeComponent::Update_Bat(CHitterBat& Bat)
{
	// flying ball�϶��� ball location�� update�Ѵ�
	if (Bat.Type == 1)
	{
		Bat.idxTrack++;
		// ������ ��
		if (Bat.idxTrack >= Bat.Track.Track.size())
		{
			Bat.idxTrack--;
			Bat.Type = 2;
		}
	}
}


void CModeComponent::Update_BatLocation(CHitterBat& Bat)
{
	if (Bat.Type == 0)
	{
		// Bat ���콺 ��ġ ã��
		dvec2 pos; glfwGetCursorPos(Window, &pos.x, &pos.y);
		Bat.SetLocation(pos, StrikeZonePoint_x, StrikeZonePoint_y);
	}
}


void CModeComponent::CheckBatHit(CBall& BaseBall, CHitterBat& Bat, double Power)
{
	if (BaseBall.idxTrack == 0 || Bat.Type != 1) return;
	int Result;

	Result = Bat.IsHit(BaseBall);
	if (Result != 0) // If hit
	{
		dvec2 pos; glfwGetCursorPos(Window, &pos.x, &pos.y);
		vec2 npos = cursor_to_ndc(pos, window_size);

		BaseBall.ResultStatus = Result;
		BaseBall.Track.idxTrackMovement = BaseBall.idxTrack;
		BaseBall.TrackCollision.Origin = Bat.Collision(BaseBall);
		BaseBall.TrackCollision.Origin.velocity *= Power;

		//printf("velocity %g (%g %g %g)\n", BaseBall.Track.Origin.velocity.length(), BaseBall.Track.Origin.velocity.x, BaseBall.Track.Origin.velocity.y, BaseBall.Track.Origin.velocity.z);
		//printf("spin (%g)\n", BaseBall.Track.Origin.spin);

		BaseBall.CollisionBall(1.0f / framefps);
	}
}


double CModeComponent::GetPitcherMinigameAccuracy(double BoardCursor)
{
	int i;
	double Sum = 0;

	for (i = 0; i < 4; i++)
	{
		Sum += PitchMinigameWeight[i];
		if (BoardCursor <= Sum) break;
	}

	if (i == 4) i = 0;
	if (i == 0 && rand() % 2 == 0) return 0;
	else return PitcherPitchMinigameAccuracy[i];
}


double CModeComponent::RandomAccuracy(int Type)
{
	int i;
	double BoardCursor = rand() % 100, Sum = 0, Gob[4] = { 1, 1, 1.5, 2 };

	for (i = 3; i > 0; i--)
	{
		Sum += PitchMinigameWeight[i] * Gob[i];
		if (BoardCursor <= Sum) break;
	}

	if (i == 0 && rand() % 2 == 0) return 0;// ���� ���� �ݹ�
	else if (Type == 0) return BatterPitchMinigameAccuracy[i];
	else return PitcherPitchMinigameAccuracy[i];
}


void CModeComponent::Set_PitcherMinigame(double Strength)
{
	PitcherCursorVelocity = 1.0f / Strength / 1.0f; // �ӵ� ����! �⺻ 1��
	if (PitcherCursorVelocity > 3) PitcherCursorVelocity = 3; // �ִ� 0.33��

	// 0 40 20 30 10
	if (Strength >= 0.9f)
	{
		PitchMinigameWeight[0] = 0, PitchMinigameWeight[1] = 40, PitchMinigameWeight[2] = 20 + 100 * (1.0f - Strength), PitchMinigameWeight[3] = 30 - 100 * (1.0f - Strength), PitchMinigameWeight[4] = 10;
	}
	// 0 40 30 20 10
	else if (Strength >= 0.5f)
	{
		PitchMinigameWeight[0] = 50 * (0.9f - Strength), PitchMinigameWeight[1] = 40 - 25 * (0.9f - Strength), PitchMinigameWeight[2] = 30 - 25 * (0.9f - Strength), PitchMinigameWeight[3] = 20 - 25 * (0.9f - Strength), PitchMinigameWeight[4] = 10 + 25 * (0.9f - Strength);
	}
	// 20 30 20 10 20
	// 30 20 20 0 30
	else
	{
		PitchMinigameWeight[0] = 30, PitchMinigameWeight[1] = 40 * (1.0f - Strength), PitchMinigameWeight[2] = 40 * Strength, PitchMinigameWeight[3] = 0, PitchMinigameWeight[4] = 30;
	}
	// 30 40 0 0 30

}
