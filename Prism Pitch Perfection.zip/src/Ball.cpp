#include "Ball.h"
#include "Utility.h"

extern vec3 StrikeZoneSize;

CBall::CBall(void)
{
	Track.Origin.location = dvec3(0, 0, -1);
	InitBall(0.0362f, 0.145f);
	ClearBall();
}

CBall::~CBall(void)
{
}

CBall& CBall::operator = (CBall Ball)
{
	this->CustomiSpin = Ball.CustomiSpin;
	this->CustomiVelocity = Ball.CustomiVelocity;
	this->idxTrack = Ball.idxTrack;
	this->Track = Ball.Track;
	this->balltype = Ball.balltype;
	this->ResultStatus = Ball.ResultStatus;
	this->ResultStrike = Ball.ResultStrike;
	this->nowframe = Ball.nowframe;
	this->BallZone = Ball.BallZone;
	this->BallZone_visible = Ball.BallZone_visible;

	return *this;
}

void CBall::InitBall(double Size, double Mass)
{
	this->Track.Property.InitProperty(Size, Mass, 0);
	this->TrackCollision.Property.InitProperty(Size, Mass, 0);
}

void CBall::ClearBall(void)
{
	balltype = 0;
	ResultStatus = ResultStrike = 0;
	Track.Track.clear();
	idxTrack = 0;
	TrackCollision.Track.clear();
	idxTrackCollision = 0;
	BallZone_visible = false;
	Track.Property.name[0] = 0;
	Track.Property.frequency = 0;
	Track.Property.proficiency = 0;
	CustomiSpin = CustomiVelocity = ivec2(0, 0);
	Track.Origin = CBallFactor();
}

void CBall::ThrowBall(double frame, double End)
{
	this->idxTrack = 0;
	this->balltype = 0;
	this->Track.Property.frame = frame;
	this->Track.Track.clear();
	this->Track.CalculateTrack(End);
	this->BallZone = Track.PredictTrack_y(0);
	this->ResultStrike = IsStrike();
	//this->ResultStatus = ResultStrike;
}


void CBall::CollisionBall(double frame)
{
	int idxnow;
	dvec3 location;

	this->balltype = 3;
	this->idxTrackCollision = 0;
	this->TrackCollision.Property.frame = frame;
	this->TrackCollision.Track.clear();

	CollisionDistance = dvec3(0, 0, 0);
	while (1)
	{
		idxnow = TrackCollision.Track.size();
		TrackCollision.CalculateTrack(-1000.0f);
		TrackCollision.Track.pop_back();

		TrackCollision[TrackCollision.Track.size() - 1].location.z = 0;
		location = TrackCollision[TrackCollision.Track.size() - 1].location;
		if (CollisionDistance == dvec3(0, 0, 0)) CollisionDistance = location;
		if (location.y > 0 && (location.x - location.y) * (location.x + location.y) < 0 // �Ŀ�üũ
			&& (TrackCollision.Track.size() - idxnow) * TrackCollision.Property.frame < 3.0f // ü���ð� 3�� �̳�
			&& TrackCollision[TrackCollision.Track.size() - 1].velocity_length() >= 0.1 * 1000.0f / 3600.0f) // 1km �̻�
		{
			TrackCollision.Origin = TrackCollision[TrackCollision.Track.size() - 1];
			TrackCollision.Origin.velocity.z *= -1;
			TrackCollision.Origin.velocity *= TrackCollision.Property.e_g;
		}
		else break;
	}
}


int CBall::IsStrike(void)
{
	dvec3 location = BallZone.location;
	double BallSize = Track.Property.size - 0.001f;
	double d1, d2, d3, d4;
	//location.y = 0
	// (-StrikeZoneSize.z, StrikeZoneSize.x)���� (StrikeZoneSize.z, StrikeZoneSize.y)
	// (location.x, location.y)

	// �ƿ� ��Ʈ����ũ�� ���� ��������
	if (-StrikeZoneSize.z <= location.x && location.x <= StrikeZoneSize.z && StrikeZoneSize.x <= location.z && location.z <= StrikeZoneSize.y) return true;
	// �𼭸�, x�ุ ����
	else if (-StrikeZoneSize.z <= location.x && location.x <= StrikeZoneSize.z)
	{
		d1 = fabs(location.z - StrikeZoneSize.x);
		d2 = fabs(location.z - StrikeZoneSize.y);
		if (d1 <= BallSize || d2 <= BallSize) return 1;
		else return 0;
	}
	// �𼭸�, y�ุ ����
	else if (StrikeZoneSize.x <= location.z && location.z <= StrikeZoneSize.y)
	{
		d1 = fabs(location.x + StrikeZoneSize.z);
		d2 = fabs(location.x - StrikeZoneSize.z);
		if (d1 <= BallSize || d2 <= BallSize) return 1;
		else return 0;
	}
	// ������
	else
	{
		d1 = (location.x + StrikeZoneSize.z) * (location.x + StrikeZoneSize.z) + (location.z - StrikeZoneSize.x) * (location.z - StrikeZoneSize.x); // (-StrikeZoneSize.z, StrikeZoneSize.x)
		d2 = (location.x + StrikeZoneSize.z) * (location.x + StrikeZoneSize.z) + (location.z - StrikeZoneSize.y) * (location.z - StrikeZoneSize.y); // (-StrikeZoneSize.z, StrikeZoneSize.y)
		d3 = (location.x - StrikeZoneSize.z) * (location.x - StrikeZoneSize.z) + (location.z - StrikeZoneSize.x) * (location.z - StrikeZoneSize.x); // (StrikeZoneSize.z, StrikeZoneSize.x)
		d4 = (location.x - StrikeZoneSize.z) * (location.x - StrikeZoneSize.z) + (location.z - StrikeZoneSize.y) * (location.z - StrikeZoneSize.y); // (StrikeZoneSize.z, StrikeZoneSize.y)
		if (d1 <= BallSize * BallSize || d2 <= BallSize * BallSize || d3 <= BallSize * BallSize || d4 <= BallSize * BallSize) return 1;
		else return 0;
	}
}
