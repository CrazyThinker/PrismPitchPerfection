#include "Pitcher.h"
#include "Utility.h"

using namespace std;

extern uint min_velocity_angle;


CPitcher::CPitcher(void)
{
	this->Strength = 1.00f;
	this->TotalFrequency = 0;
	this->PitchCount = 100;
}


CPitcher::~CPitcher(void)
{
}



bool CPitcher::LoadPitcher(const char* szFileName, CBallProperty Property)
{
	int i, j;
	char szText[1024];
	CBallTrace tmpBall;

	FILE* fi = fopen(szFileName, "r");
	if (fi == NULL) return false;

	this->TotalFrequency = 0;
	this->PitchBall.clear();
	tmpBall.Property = Property;
	strcpy(tmpBall.Property.name, "None");
	PitchBall.push_back(tmpBall);

	while (1)
	{
		if (fscanf(fi, "%s", szText) == EOF) break;
		if (strcmp(szText, "ball") == 0)
		{
		}
		else if (strcmp(szText, "/ball") == 0)
		{
			this->PitchBall.push_back(tmpBall);
			this->TotalFrequency += tmpBall.Property.frequency;
		}
		else if (strcmp(szText, "name") == 0)
		{
			fscanf(fi, "%s", tmpBall.Property.name);
			for (j = strlen(tmpBall.Property.name) - 1; j >= 0; j--) if (tmpBall.Property.name[j] == '_') tmpBall.Property.name[j] = ' ';
		}
		else if (strcmp(szText, "location") == 0)
		{
			fscanf(fi, "%lf%lf%lf", &tmpBall.Origin.location.x, &tmpBall.Origin.location.y, &tmpBall.Origin.location.z);
		}
		else if (strcmp(szText, "velocity") == 0)
		{
			fscanf(fi, "%lf", &tmpBall.Origin.velocity);
			tmpBall.Origin.velocity *= 1000.0f / 3600.0f;
		}
		else if (strcmp(szText, "angle") == 0)
		{
			fscanf(fi, "%lf%lf%lf", &tmpBall.Origin.angle.x, &tmpBall.Origin.angle.y, &tmpBall.Origin.angle.z);
		}
		else if (strcmp(szText, "spin_euler") == 0)
		{
			fscanf(fi, "%lf%lf", &tmpBall.Origin.spin_euler.x, &tmpBall.Origin.spin_euler.y);
		}
		else if (strcmp(szText, "spin") == 0)
		{
			fscanf(fi, "%lf", &tmpBall.Origin.spin);
			tmpBall.Origin.spin *= 2.0 * PI / 60.0f;
		}
		else if (strcmp(szText, "proficiency") == 0)
		{
			fscanf(fi, "%lf", &tmpBall.Property.proficiency);
		}
		else if (strcmp(szText, "frequency") == 0)
		{
			fscanf(fi, "%d", &tmpBall.Property.frequency);
		}
		else if (strcmp(szText, "pitchcount") == 0)
		{
			fscanf(fi, "%d", &PitchCount);
		}
		else printf("Error: Wrong String [%s]\n", szText);
	}
	fclose(fi);

	return true;
}


bool CPitcher::SavePitcher(const char* szFileName)
{
	int i, j, len, nPitchBall = PitchBall.size() - 1;

	FILE* fo = fopen(szFileName, "w");
	if (fo == NULL) return false;

	for (i = 1; i <= nPitchBall; i++)
	{
		fprintf(fo, "ball\n");
		fprintf(fo, "name ");
		len = strlen(PitchBall[i].Property.name);
		for (j = 0; j < len; j++)
		{
			if (PitchBall[i].Property.name[j] == ' ') fprintf(fo, "_");
			else fprintf(fo, "%c", PitchBall[i].Property.name[j]);
		}
		fprintf(fo, "\n");
		fprintf(fo, "location %g %g %g\n", PitchBall[i].Origin.location.x, PitchBall[i].Origin.location.y, PitchBall[i].Origin.location.z);
		fprintf(fo, "velocity %g\n", PitchBall[i].Origin.velocity_length() / 1000.0f * 3600.0f);
		fprintf(fo, "angle %g %g %g\n", PitchBall[i].Origin.angle.x, PitchBall[i].Origin.angle.y, PitchBall[i].Origin.angle.z);
		fprintf(fo, "spin_euler %g %g\n", PitchBall[i].Origin.spin_euler.x, PitchBall[i].Origin.spin_euler.y);
		fprintf(fo, "spin %g\n", PitchBall[i].Origin.spin * 60.0f / 2.0 / PI);
		fprintf(fo, "proficiency %g\n", PitchBall[i].Property.proficiency);
		fprintf(fo, "frequency %d\n", PitchBall[i].Property.frequency);
		fprintf(fo, "/ball\n\n");
	}
	fprintf(fo, "pitchcount %d\n", PitchCount);

	fclose(fo);

	return true;
}



int CPitcher::RandomBallType(void)
{
	int i, r, nPitchBall = PitchBall.size();

	if (TotalFrequency == 0) return 0;
	r = rand() % TotalFrequency;
	for (i = 1; i <= nPitchBall - 1; i++)
	{
		r -= PitchBall[i].Property.frequency;
		if (r < 0) break;
	}

	return i;
}


CBallTrace CPitcher::UpdateCondition(CBallTrace &Ball)
{
	double vr = 0, sr = 0, v, s;

	// ���������� ü��75%����
	if (Strength <= 0.75f) // ü���� 75% ���ϸ� ���Ӱ� ȸ������ ��������
	{
		vr += (0.75f - Strength) * 0.04f; // ü�¿� ���� �ִ� ������ 3%��ŭ ������ ��������
		sr += (0.75f - Strength) * 0.06f; // ü�¿� ���� �ִ� ȸ������ 4.5%��ŭ ȸ������ ��������
	}

	// ���� 3%, ȸ���� 4.5% ������
	if (Strength <= 0.25f) // �ִ� ü���� 30% ���ϸ� ���Ӱ� ȸ������ ��������
	{
		vr += (0.25f - Strength) * 0.12f; // ü�¿� ���� �ִ� ������ 6%��ŭ ������ ��������
		sr += (0.25f - Strength) * 0.18f; // ü�¿� ���� �ִ� ȸ������ 9%��ŭ ȸ������ ��������
	}
	// ���� 6%, ȸ���� 9% ������

	v = 1 - (1.0f - Strength) * vr;
	s = 1 - (1.0f - Strength) * sr;

	Ball.Origin.velocity *= v;
	Ball.Origin.spin *= s;

	return Ball;
}


dvec2 CPitcher::RandomCourse(tuple<ivec2, ivec2, ivec2> iVelocity, int Cursor)
{
	/*
	    11    10    9
	0   12/20 19/27 18/26 8
	1   13/21 28    17/25 7
	2   14/22 15/23 16/24 6
	    3     4     5

	// ������ 12, ��� 28, �����ʾƷ� 16
	// 12~19������ �ݹ����� �ѹ��� 20~27
	*/
	int i, r;
	int Weight[] = {
		5, 10, 5, 5, 10, 5, 5, 10, 5, 5, 10, 5, 
		10, 20, 10, 20, 10, 20, 10, 20,
		15, 25, 15, 25, 15, 25, 15, 25,
		0 };
	int nWeight = sizeof(Weight) / sizeof(Weight[0]) - 1, TotalWeight = 0;

	ivec2 TopLeft = get<0>(iVelocity), Center = get<1>(iVelocity), BottomRight = get<2>(iVelocity);
	dvec2 Result;
	double TopBottom[6] = { (TopLeft.y * 5 - Center.y) / 4, TopLeft.y, (TopLeft.y * 3 + Center.y) / 4, (BottomRight.y * 3 + Center.y) / 4, BottomRight.y, (BottomRight.y * 5 - Center.y) / 4 };
	double LeftRight[6] = { (TopLeft.x * 5 - Center.x) / 4, TopLeft.x, (TopLeft.x * 3 + Center.x) / 4, (BottomRight.x * 3 + Center.x) / 4, BottomRight.x, (BottomRight.x * 5 - Center.x) / 4 };

	for (i = 1; i <= nWeight; i++) TotalWeight += Weight[i];
	r = rand() % TotalWeight;
	for (i = 1; i <= nWeight; i++)
	{
		r -= Weight[i];
		if (r < 0) break;
	}

	switch (i)
	{
	case 0: Result = dvec2(LeftRight[0], TopBottom[2]);
		break;

	case 1: Result = dvec2(LeftRight[0], Center.y);
		break;

	case 2: Result = dvec2(LeftRight[0], TopBottom[3]);
		break;

	case 3: Result = dvec2(LeftRight[2], TopBottom[5]);
		break;

	case 4: Result = dvec2(Center.x, TopBottom[5]);
		break;

	case 5: Result = dvec2(LeftRight[3], TopBottom[5]);
		break;

	case 6: Result = dvec2(LeftRight[5], TopBottom[3]);
		break;

	case 7: Result = dvec2(LeftRight[5], Center.y);
		break;

	case 8: Result = dvec2(LeftRight[5], TopBottom[2]);
		break;

	case 9: Result = dvec2(LeftRight[3], TopBottom[0]);
		break;

	case 10: Result = dvec2(Center.x, TopBottom[0]);
		break;

	case 11: Result = dvec2(LeftRight[2], TopBottom[0]);
		break;

	case 12: Result = dvec2(LeftRight[1], TopBottom[1]);
		break;

	case 13: Result = dvec2(LeftRight[1], Center.y);
		break;

	case 14: Result = dvec2(LeftRight[1], TopBottom[4]);
		break;

	case 15: Result = dvec2(Center.x, TopBottom[4]);
		break;

	case 16: Result = dvec2(LeftRight[4], TopBottom[4]);
		break;

	case 17: Result = dvec2(LeftRight[4], Center.y);
		break;

	case 18: Result = dvec2(LeftRight[4], TopBottom[1]);
		break;

	case 19: Result = dvec2(Center.x, TopBottom[1]);
		break;

	case 20: Result = dvec2(LeftRight[2], TopBottom[2]);
		break;

	case 21: Result = dvec2(LeftRight[2], Center.y);
		break;

	case 22: Result = dvec2(LeftRight[2], TopBottom[3]);
		break;

	case 23: Result = dvec2(Center.x, TopBottom[3]);
		break;

	case 24: Result = dvec2(LeftRight[3], TopBottom[3]);
		break;

	case 25: Result = dvec2(LeftRight[3], Center.y);
		break;

	case 26: Result = dvec2(LeftRight[3], TopBottom[2]);
		break;

	case 27: Result = dvec2(Center.x, TopBottom[2]);
		break;

	case 28: Result = dvec2(Center.x, Center.y);
		break;

	}

	return Result;
}



CBallTrace CPitcher::RandomBall(CBallTrace Ball, dvec2 CustomiVelocity, double Accuracy)
{
	double v, s;
	double random_ra, random_th;
	dvec2 random_v;
	dvec3 minBoundary;
	CBallTrace Factor;

	Factor = Ball;
	// velocity
	v = Factor.Origin.velocity_length() * GetRandom(0.985f, 1.015f); // ���� ���̴� 1.5%
	//v *= 1 - (1.0f - Strength) * 0.05f; �̹� ����������
	random_ra = 50 * GetRandom(1 - Accuracy, 1 - Factor.Property.proficiency * Accuracy);
	random_th = GetRandom(0, 2 * PI);
	random_v = dvec2(CustomiVelocity.x + random_ra * cos(random_th), CustomiVelocity.y + random_ra * sin(random_th)) * PI / min_velocity_angle;

	Factor.Origin.velocity = EulerAngle(random_v) * v;

	// spin
	s = Factor.Origin.spin * GetRandom(0.95f, 1.05f); // ȸ���� ���̴� 5%
	//s *= 1 - (1.0f - Strength) * 0.05f; �̹� ������ ����
	Factor.Origin.spin = s;

	Expenditure();
	return Factor;
}


void CPitcher::Expenditure(void)
{
	Strength -= 1.0f / PitchCount;
	if (Strength < 0) Strength = 0;
}
