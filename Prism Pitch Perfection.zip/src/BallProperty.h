#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility

class CBallProperty
{
public:
	CBallProperty(void);
	~CBallProperty(void);
	CBallProperty& operator = (CBallProperty BallProperty);
	bool operator == (CBallProperty Factor) const;
	bool operator != (CBallProperty Factor) const;

public:
	char name[30];						// �̸�
	int frequency;						// ��
	double proficiency;					// ���õ�

public:
	// ������ kg, m, s
	double size;						// Ball radius size
	double mass;						// ball mass
	double frame;

public:
	const double rho = 1.23f;
	const double pi = 3.141592653589793f;
	// �⺻�� ����
	double g = 9.80665f;
	double C_d = 0.40f;
	double C_l = 0.44f;
	double e_v = 0.6092f;
	double e_g = 0.5f;

public:
	void InitProperty(double size, double mass, double frame);

};
