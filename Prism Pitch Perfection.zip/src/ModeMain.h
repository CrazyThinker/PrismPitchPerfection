#pragma once
#include "ModeComponent.h"
#include "ModeOpening.h"
#include "ModeCustom.h"
#include "ModeBatter.h"
#include "ModePitcher.h"

class CModeMain : public CModeComponent
{
public:
	CModeMain(void);
	~CModeMain(void);

public:
	int beforeProgramMode;

	CModeOpening ModeOpening;
	CModeCustom ModeCustom;
	CModeBatter ModeBatter;
	CModePitcher ModePitcher;

public:
	void Initialize_Main(void);

	void Initialize(void); // üũ�ϸ鼭
	void Render(void);
	void Update(void);
	void Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods);
	void Mouse(GLFWwindow* window, int button, int action, int mods);
	void Exception(void);

};
