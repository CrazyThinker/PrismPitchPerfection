#include "BallFactor.h"


CBallFactor::CBallFactor(void)
{
	location = dvec3(0, 0, 0);
	velocity = dvec3(0, 0, 0);
	angle = dvec3(0, 0, 0);
	spin = 0;
	spin_euler = dvec2(0, 0);
	spin_angle = 0;
}


CBallFactor::~CBallFactor(void)
{
}



double CBallFactor::velocity_length(void)
{
	return velocity.length();
}


dvec3 CBallFactor::velocity_angle(void)
{
	if (velocity.length() == 0) return velocity;
	else return velocity.normalize();
}
