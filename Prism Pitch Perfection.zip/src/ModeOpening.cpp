#include "ModeOpening.h"


CModeOpening::CModeOpening(void)
{
}


CModeOpening::~CModeOpening(void)
{
}


void CModeOpening::Initialize(void)
{
}


void CModeOpening::Render(void)
{
	float dpi_scale, tmp, size;
	float ct, st, q, cq, sq;

	dpi_scale = cg_get_dpi_scale();
	float a = abs(sin(Main->t * 2.5f));

	Main->Render_Text("Prism Pitch Perfection", 80, 100, 1.0f, vec4(0.5f, 0.8f, 0.2f, a), dpi_scale);
	if (Cursor == 1) tmp = 1.0f, size = 0.6f;
	else tmp = 0.4f, size = 0.55f;
	Main->Render_Text("Custom Mode", 100, 150, size, vec4(0.4f, 0.7f, 0.7f, tmp), dpi_scale);
	if (Cursor == 2) tmp = 1.0f, size = 0.6f;
	else tmp = 0.4f, size = 0.55f;
	Main->Render_Text("Batter Mode", 100, 190, size, vec4(0.2f, 0.6f, 0.7f, tmp), dpi_scale);
	if (Cursor == 3) tmp = 1.0f, size = 0.6f;
	else tmp = 0.4f, size = 0.55f;
	Main->Render_Text("Pitcher Mode", 100, 230, size, vec4(0.7f, 0.4f, 0.1f, tmp), dpi_scale);
	if (Cursor == 4) tmp = 1.0f, size = 0.6f;
	else tmp = 0.4f, size = 0.55f;
	Main->Render_Text("Settings", 100, 270, size, vec4(0.8f, 0.6f, 0.3f, tmp), dpi_scale);
	if (Cursor == 5) tmp = 1.0f, size = 0.6f;
	else tmp = 0.4f, size = 0.55f;
	Main->Render_Text("Exit ?", 100, 310, size, vec4(0.2f, 0.8f, 0.2f, tmp), dpi_scale);

	glUseProgram(Main->Program);
}


void CModeOpening::Update(void)
{
}


void CModeOpening::Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (action == GLFW_PRESS)
	{
		if (key == GLFW_KEY_ESCAPE || key == GLFW_KEY_Q) Main->ProgramMode = -100; // Exit
		else if (key == GLFW_KEY_UP)
		{
			if (Cursor > 1) Cursor--;
		}
		else if (key == GLFW_KEY_DOWN)
		{
			if (Cursor < 5) Cursor++;
		}
		else if (key == GLFW_KEY_ENTER)
		{
			if (Cursor == 1) // Custom Mode
			{
				Main->ProgramMode = 10;
			}
			else if (Cursor == 2) // Batter Mode
			{
				Main->ProgramMode = 20;

				/*
				move_camera_direction = false;
				BaseBall.balltype = 0;
				BaseBall.BallZone_visible = false;
				BallCursor = 0;
				BatterMode_init();
				PitcherList = CFileList("..\\bin\\pitcherball\\", "ball");
				PitcherList.GetList();
				engine->play2D(sound_gamestart);

				//printf("- Click to swing the bat. \n\n");
				*/
			}
			else if (Cursor == 3) // Pitcher Mode
			{
				Main->ProgramMode = 30;
			}
			else if (Cursor == 4) // Settings
			{
				MessageBox(NULL, L"���� ���� �� ���α׷��� ������ؾ� ������ ����˴ϴ�.", L"Prism Pitch Perfection", 0);
				system("start settings.txt");
				//engine->play2D(sound_select);
			}
			else Main->ProgramMode = -100; // Exit
		}
	}
}


void CModeOpening::Mouse(GLFWwindow* window, int button, int action, int mods)
{
}
