#pragma once
#include "ModeComponent.h"

class CModeOpening
{
public:
	CModeOpening(void);
	~CModeOpening(void);

public:
	CModeComponent* Main;
	int Cursor = 1;

public:
	void Initialize(void);
	void Render(void);
	void Update(void);
	void Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods);
	void Mouse(GLFWwindow* window, int button, int action, int mods);

};
