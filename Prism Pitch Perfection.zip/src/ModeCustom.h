#pragma once
#include "ModeComponent.h"
#include "Ball.h"
#include "Pitcher.h"

#define MAX_BALL 7

class CModeCustom : public CModeComponent
{
public:
	CModeCustom(void);
	~CModeCustom(void);

public:
	CModeComponent* Main;
	int BallCursor; // 0 To Simulate
	int PitchFormCursor; // PitchForm
	int EditCursor; // ���� ����
	int DetailCursor; // ������ ����
	int nBaseBall = MAX_BALL;
	char InputDetail[100] = { 0 };
	string InputTitle;
	int InputType = 0; // 1: String, 2: Natural Number, 3: Real Number
	CBall BaseBall[MAX_BALL + 1]; // BaseBall
	double Proficiency[MAX_BALL + 1] = { 0 };
	int Frequency[MAX_BALL + 1] = { 0 };
	int TotalBallType;
	double CustomVelocity = 0;
	double CustomSpin = 0;
	ivec2 CustomiVelocity;
	ivec2 CustomiSpin;

	const int nPitchFormInformation = 9;
	const pair<string, dvec3> PitchFormInformation[10] =
	{
		make_pair("", dvec3(0, 0, 0)),
		make_pair("Left Overhand", dvec3(0.215f + 0.588 * cos(PI / 3), 18.44f - 1.78f, 1.41f + 0.215f + 0.588 * sin(PI / 3))),
		make_pair("Left 3-quarter", dvec3(0.215f + 0.588 * cos(PI / 6), 18.44f - 1.78f, 1.41f + 0.215f + 0.588 * sin(PI / 6))),
		make_pair("Left Sidearm", dvec3(0.215f + 0.588 * cos(0), 18.44f - 1.78f, 1.063f + 0.215f + 0.588 * sin(0))),
		make_pair("Left Underhand", dvec3(0.25f + 0.588 * cos(-PI / 4), 18.44f - 1.78f, 1.063f + 0.215f + 0.588 * sin(-PI / 3))),

		make_pair("Right Overhand", dvec3(-0.215f - 0.588 * cos(PI / 3), 18.44f - 1.78f, 1.41f + 0.215f + 0.588 * sin(PI / 3))),
		make_pair("Right 3-quarter", dvec3(-0.215f - 0.588 * cos(PI / 6), 18.44f - 1.78f, 1.41f + 0.215f + 0.588 * sin(PI / 6))),
		make_pair("Right Sidearm", dvec3(-0.215f - 0.588 * cos(0), 18.44f - 1.78f, 1.063f + 0.215f + 0.588 * sin(0))),
		make_pair("Right Underhand", dvec3(-0.25f - 0.588 * cos(-PI / 4), 18.44f - 1.78f, 1.063f + 0.215f + 0.588 * sin(-PI / 3))),
		make_pair("Custom PitchForm", dvec3(0, 0, 0))
	};


public:
	void Initialize(void);
	void Update(void);
	void Render(void);
	void Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods);
	void Mouse(GLFWwindow* window, int button, int action, int mods);

	void Render_BallInformation(CBall& Ball, int Edit = 0);
	void Render_InputDetail(void);
	void Update_Custom(void);

	void SaveFile(void);
	void OpenFile(void);

};
