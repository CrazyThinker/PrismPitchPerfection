#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility
#include "trackball.h"	// virtual trackball

#include "BallTrace.h"

using namespace std;

class CBall
{
public:
	CBall(void);
	~CBall(void);
	CBall& operator = (CBall Ball);

public:
	ivec2 CustomiSpin, CustomiVelocity;
	int idxTrack;
	CBallTrace Track;
	int idxTrackCollision;
	CBallTrace TrackCollision;
	dvec3 CollisionDistance;

	int balltype;							// ball type, 0: stoping ball, 1: flying ball, 2: resting ball
	int ResultStatus;						// 0: ball, 1: strike, 2: strike with swing, 3: hit
	int ResultStrike;						// 0: ball, 1: strike
	double nowframe;

	CBallFactor BallZone;					// ��Ʈ����ũ���� ǥ�õ� ��
	bool BallZone_visible;					// ��Ʈ����ũ���� ǥ�õ� ���� ����

public:
	void InitBall(double Size, double Mass);
	void ClearBall(void);
	void ThrowBall(double frame, double End = -2.655f);
	void CollisionBall(double frame);
	int IsStrike(void);

};
