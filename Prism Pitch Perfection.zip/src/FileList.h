#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility

using namespace std;

class CFileList
{
public:
	CFileList(void);
	CFileList(string folder, string extension);
	~CFileList(void);

public:
	string folder;
	string extension;

public:
	vector<string> FileList;

public:
	void GetList(void);

};
