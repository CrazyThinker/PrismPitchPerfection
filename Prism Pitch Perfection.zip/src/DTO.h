#pragma once
#include <string>
#include "BallProperty.h"
#include "BallFactor.h"
//#include "Pitcher.h"

using std::string;

class CBallPropertyDTO
{
public:
	CBallPropertyDTO(void);
	~CBallPropertyDTO(void);

public: // ������
	char name[30];						// �̸�
	int frequency;						// ��
	double proficiency;					// ���õ�

	double size;						// Ball radius size
	double mass;						// ball mass
	double frame;

	double g;
	double C_d;
	double C_l;
	double e_v;
	double e_g;

public:
	void SetBallProperty(CBallProperty data);
	CBallProperty GetBallProperty(void);
	string Serialize(void);
	void Deserialize(string String);

};


class CBallFactorDTO
{
public:
	CBallFactorDTO(void);
	~CBallFactorDTO(void);

public:
	dvec3 location;							// ball location
	dvec3 velocity;							// ball velocity
	dvec3 angle;							// ball initial angle
	double spin;							// ball spin
	dvec2 spin_euler;						// ball spin euler
	double spin_angle;						// ball spin angle (0~2pi)    dvec3 velocity_angle;

public:
	void SetBallFactor(CBallFactor data);
	CBallFactor GetBallFactor(void);
	string Serialize(void);
	void Deserialize(string String);

};
